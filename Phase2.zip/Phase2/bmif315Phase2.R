## created by: Robert Cronin
## BMIF 315
## Spring 2014


## ADAPTED FROM:
# Version info: R 2.14.1, Biobase 2.15.3, GEOquery 2.23.2, limma 3.10.1
# R scripts generated  Mon Jan 13 14:07:19 EST 2014
################################################################



#   Boxplot for selected GEO samples
source("http://bioconductor.org/biocLite.R")
biocLite("Biobase")
biocLite("GEOquery")

library(Biobase)
library(GEOquery)

# load series and platform data from GEO

## Set the directory to my working directory
setwd("C:\\Users\\croninrm\\Documents\\BMI-Fellow-PGY1\\BMIF315\\Project\\Phase2")

gset10245 <- getGEO("GSE10245", GSEMatrix =TRUE)
if (length(gset10245) > 1) idx <- grep("GPL570", attr(gset10245, "names")) else idx <- 1
gset10245 <- gset10245[[idx]]


gset18842 <- getGEO("GSE18842", GSEMatrix =TRUE)
if (length(gset18842) > 1) idx <- grep("GPL570", attr(gset18842, "names")) else idx <- 1
gset18842 <- gset18842[[idx]]  

#########################################################################################
#########################################################################################
#### THIS IS GSE10245
#########################################################################################
#########################################################################################

#Getting disease states adeno or SCC
dztmp = pData(gset10245)[,10]

#make them integers we can discern
#0 is adenocarcinoma, 1 is squamous cell carcinoma
outcome= as.integer(dztmp)-1

#now create the data frame
#I end up transposing the rows and columns to make it
#The way it should be, meaning rows are samples and 
#columns are the features
datas=t(exprs(gset10245))

#add the outcome to the features at the end of the matrix
dframe = cbind(datas,outcome)

#turn it into a dataframe
dframe = data.frame(dframe)

#display dimensions
cat("Dimensions:rows=",dim(dframe)[1],", cols=",dim(dframe)[2])

#save the full data frame for analysis
write.csv(dframe, "output\\mydataframe_1.csv")

#create a blank vector
notMissingfraction = rep(0.200,ncol(dframe))

#Check for any missingness of data
for (i in 1:ncol(dframe)) {

  #find the number of missing elements as a double
  #this returns a vector of 1 or 0 if the column
  #is missing any data
  missings=as.double(is.na(dframe[,i]))
  
  #Now sum the number of missings in the vector and 
  #divide by the number of rows of the data frame
  notMissingfraction[i] = 1-(sum(missings)/nrow(dframe))
  
}

#Create the data frame for the features and write it to a csv
nonMissdf=cbind(colnames(dframe),(notMissingfraction))
colnames(nonMissdf)=c("Feature","Non-missing fraction")
write.csv(nonMissdf,"output\\mydataframeComplete_1.csv", row.names=FALSE)

#This is the histogram of the data missingness
completePNG=hist(notMissingfraction, breaks=seq(0,1,0.1),xlim=c(0,1),ylim=c(0,60000), xlab="Fraction of values present", ylab="Number of Features", main="Histogram of features and fraction of values present")
completePNG$xname = "Fraction of values present"
#plot and save it
mypath <- file.path(paste(getwd(),"/output",sep=""),"featureCompleteness_1.png")
png(file=mypath, width=1200, height=800)
plot(completePNG)
dev.off()

#Plot the target distribution here, y axis is the outcome, and save it
mypath <- file.path(paste(getwd(),"/output",sep=""),"targetDist_1.png")
png(file=mypath, width=1200, height=800)
plot(seq(1,nrow(dframe),1),outcome, xlab="Sample # ", ylab="outcome, 0=AC, 1=SCC")
dev.off()
dev.off()
dev.off()

#this creates a smaller data frame with two features and the outcome as columns for our
#xy scatterplot
ind=c(1,2,ncol(dframe))
sub_dframe = dframe[,ind]
sub_dframe$outcome = as.factor(sub_dframe$outcome)


#Now that we have the data frame, we will create the x,y scatter plot
xyPlot = qplot(data=sub_dframe,x=sub_dframe$X1007_s_at,y=sub_dframe$X1053_at,color=sub_dframe$outcome)
xyPlot = xyPlot + labs(title = expression("Adenocarcimona or Squamous cell carcinoma based on 2 features"))
xyPlot = xyPlot +  aes(size=8) + scale_size(range = c(8, 8))
xyPlot = xyPlot + guides(size=FALSE)
xyPlot = xyPlot + theme(legend.text = element_text(size = 12, ))
xyPlot = xyPlot +scale_colour_discrete(name = "My Legend",
                                       labels=c("Adenocarcinoma", "Squamous Cell Carcinoma"))

#plot and save it
mypath <- file.path(paste(getwd(),"/output",sep=""),"scatterx1x2Y_1.png")
png(file=mypath, width=1200, height=800)
plot(xyPlot)

#shut off the device
dev.off()





#########################################################################################
#########################################################################################
#### THIS IS GSE18842
#########################################################################################
#########################################################################################

#Getting disease states adeno or SCC
dztmp = pData(gset18842)[,11]

#make them integers we can discern
#0 is adenocarcinoma, 1 is squamous cell carcinoma
outcome= as.integer(dztmp)-1

#now create the data frame
#I end up transposing the rows and columns to make it
#The way it should be, meaning rows are samples and 
#columns are the features
datas=t(exprs(gset18842))

#add the outcome to the features at the end of the matrix
dframe = cbind(datas,outcome)

#turn it into a dataframe
dframe = data.frame(dframe)

#display dimensions
cat("Dimensions:rows=",dim(dframe)[1],", cols=",dim(dframe)[2])

#save the full data frame for analysis
write.csv(dframe, "output\\mydataframe_2.csv")

#create a blank vector
notMissingfraction = rep(0.200,ncol(dframe))

#Check for any missingness of data
for (i in 1:ncol(dframe)) {
  
  #find the number of missing elements as a double
  #this returns a vector of 1 or 0 if the column
  #is missing any data
  missings=as.double(is.na(dframe[,i]))
  
  #Now sum the number of missings in the vector and 
  #divide by the number of rows of the data frame
  notMissingfraction[i] = 1-(sum(missings)/nrow(dframe))
  
}

#Create the data frame for the features and write it to a csv
nonMissdf=cbind(colnames(dframe),(notMissingfraction))
colnames(nonMissdf)=c("Feature","Non-missing fraction")
write.csv(nonMissdf,"output\\mydataframeComplete_2.csv", row.names=FALSE)

#This is the histogram of the data missingness
completePNG=hist(notMissingfraction, breaks=seq(0,1,0.1),xlim=c(0,1),ylim=c(0,60000), xlab="Fraction of values present", ylab="Number of Features", main="Histogram of features and fraction of values present")
completePNG$xname = "Fraction of values present"
#plot and save it
mypath <- file.path(paste(getwd(),"/output",sep=""),"featureCompleteness_2.png")
png(file=mypath, width=1200, height=800)
plot(completePNG)
dev.off()

#Plot the target distribution here, y axis is the outcome, and save it
mypath <- file.path(paste(getwd(),"/output",sep=""),"targetDist_2.png")
png(file=mypath, width=1200, height=800)
plot(seq(1,nrow(dframe),1),outcome, xlab="Sample # ", ylab="outcome, 0=sample:control, 1=sample:tumor")
dev.off()
dev.off()
dev.off()

#this creates a smaller data frame with two features and the outcome as columns for our
#xy scatterplot
ind=c(1,2,ncol(dframe))
sub_dframe = dframe[,ind]
sub_dframe$outcome = as.factor(sub_dframe$outcome)


#Now that we have the data frame, we will create the x,y scatter plot
xyPlot = qplot(data=sub_dframe,x=sub_dframe$X1007_s_at,y=sub_dframe$X1053_at,color=sub_dframe$outcome)
xyPlot = xyPlot + labs(title = expression("Controle vs tumor based on 2 features"))
xyPlot = xyPlot +  aes(size=8) + scale_size(range = c(8, 8))
xyPlot = xyPlot + guides(size=FALSE)
xyPlot = xyPlot + theme(legend.text = element_text(size = 12, ))
xyPlot = xyPlot +scale_colour_discrete(name = "My Legend",
                                       labels=c("sample:control", "sample:tumor"))

#plot and save it
mypath <- file.path(paste(getwd(),"/output",sep=""),"scatterx1x2Y_2.png")
png(file=mypath, width=1200, height=800)
plot(xyPlot)

#shut off the device
dev.off()




