## created by: Robert Cronin
## BMIF 315
## Spring 2014


## ADAPTED FROM:
# Version info: R 2.14.1, Biobase 2.15.3, GEOquery 2.23.2, limma 3.10.1
# R scripts generated  Mon Jan 13 14:07:19 EST 2014
################################################################

#Clean Memory
rm(list=ls())

source("http://bioconductor.org/biocLite.R")

##IF NEED TO UPGRADE
#biocLite("BiocUpgrade")


biocLite("Biobase")
biocLite("GEOquery")

library(Biobase)
library(GEOquery)
library(ggplot2)

# load series and platform data from GEO

## Set the directory to my working directory
setwd("C:\\Users\\croninrm\\Documents\\BMI-Fellow-PGY1\\BMIF315\\Project\\Phase3")

gset10245 <- getGEO("GSE10245", GSEMatrix =TRUE)
if (length(gset10245) > 1) idx <- grep("GPL570", attr(gset10245, "names")) else idx <- 1
gset10245 <- gset10245[[idx]]


gset18842 <- getGEO("GSE18842", GSEMatrix =TRUE)
if (length(gset18842) > 1) idx <- grep("GPL570", attr(gset18842, "names")) else idx <- 1
gset18842 <- gset18842[[idx]]  

#########################################################################################
#########################################################################################
#### THIS IS GSE10245
#########################################################################################
#########################################################################################

#Getting disease states adeno or SCC
dztmp = pData(gset10245)[,10]

#make them integers we can discern
#0 is adenocarcinoma, 1 is squamous cell carcinoma
outcome= as.integer(dztmp)-1

#now create the data frame
#I end up transposing the rows and columns to make it
#The way it should be, meaning rows are samples and 
#columns are the features
datas=t(exprs(gset10245))

#add the outcome to the features at the end of the matrix
dframe = cbind(datas,outcome)

#turn it into a dataframe
dframe = data.frame(dframe)

#display dimensions
cat("Dimensions:rows=",dim(dframe)[1],", cols=",dim(dframe)[2])


#create a blank vector
notMissingfraction = rep(0.200,ncol(dframe))

#Check for any missingness of data
for (i in 1:ncol(dframe)) {

  #find the number of missing elements as a double
  #this returns a vector of 1 or 0 if the column
  #is missing any data
  missings=as.double(is.na(dframe[,i]))
  
  #Now sum the number of missings in the vector and 
  #divide by the number of rows of the data frame
  notMissingfraction[i] = 1-(sum(missings)/nrow(dframe))
  
}

#Create the data frame for the features and write it to a csv
nonMissdf=cbind(colnames(dframe),(notMissingfraction))
colnames(nonMissdf)=c("Feature","Non-missing fraction")

#This is the histogram of the data missingness
completePNG=hist(notMissingfraction, breaks=seq(0,1,0.1),xlim=c(0,1),ylim=c(0,60000), xlab="Fraction of values present", ylab="Number of Features", main="Histogram of features and fraction of values present")
completePNG$xname = "Fraction of values present for GSE10245"


#this creates a smaller data frame with two features and the outcome as columns for our
#xy scatterplot
ind=c(1,2,ncol(dframe))
sub_dframe = dframe[,ind]
sub_dframe$outcome = as.factor(sub_dframe$outcome)


#Now that we have the data frame, we will create the x,y scatter plot
xyPlot = qplot(data=sub_dframe,x=sub_dframe$X1007_s_at,y=sub_dframe$X1053_at,color=sub_dframe$outcome)
xyPlot = xyPlot + labs(title = expression("Adenocarcimona or Squamous cell carcinoma based on 2 features  for GSE10245"))
xyPlot = xyPlot +  aes(size=8) + scale_size(range = c(8, 8))
xyPlot = xyPlot + guides(size=FALSE)
xyPlot = xyPlot + theme(legend.text = element_text(size = 12, ))
xyPlot = xyPlot +scale_colour_discrete(name = "My Legend",
                                       labels=c("Adenocarcinoma", "Squamous Cell Carcinoma"))






#########################################################################################
#########################################################################################
#### THIS IS GSE18842
#########################################################################################
#########################################################################################

#Getting disease states adeno or SCC
dztmp2 = pData(gset18842)[,11]

#make them integers we can discern
#0 is adenocarcinoma, 1 is squamous cell carcinoma
outcome2= as.integer(dztmp2)-1

#now create the data frame
#I end up transposing the rows and columns to make it
#The way it should be, meaning rows are samples and 
#columns are the features
datas2=t(exprs(gset18842))

#add the outcome to the features at the end of the matrix
dframe2 = cbind(datas2,outcome2)
names(dframe2)[ncol(dframe2)]="outcome"
#turn it into a dataframe
dframe2 = data.frame(dframe2)

#display dimensions
cat("Dimensions:rows=",dim(dframe2)[1],", cols=",dim(dframe2)[2])


#create a blank vector
notMissingfraction2 = rep(0.200,ncol(dframe2))

#Check for any missingness of data
for (i in 1:ncol(dframe2)) {
  
  #find the number of missing elements as a double
  #this returns a vector of 1 or 0 if the column
  #is missing any data
  missings2=as.double(is.na(dframe2[,i]))
  
  #Now sum the number of missings in the vector and 
  #divide by the number of rows of the data frame
  notMissingfraction2[i] = 1-(sum(missings2)/nrow(dframe2))
  
}

#Create the data frame for the features and write it to a csv
nonMissdf2=cbind(colnames(dframe2),(notMissingfraction2))
colnames(nonMissdf2)=c("Feature","Non-missing fraction")

#This is the histogram of the data missingness
completePNG2=hist(notMissingfraction2, breaks=seq(0,1,0.1),xlim=c(0,1),ylim=c(0,60000), xlab="Fraction of values present", ylab="Number of Features", main="Histogram of features and fraction of values present")
completePNG2$xname = "Fraction of values present of GSE18842"


#this creates a smaller data frame with two features and the outcome as columns for our
#xy scatterplot
ind=c(1,2,ncol(dframe2))
sub_dframe2 = dframe2[,ind]
sub_dframe2$outcome = as.factor(sub_dframe2$outcome)


#Now that we have the data frame, we will create the x,y scatter plot
xyPlot2 = qplot(data=sub_dframe2,x=sub_dframe2$X1007_s_at,y=sub_dframe2$X1053_at,color=sub_dframe2$outcome)
xyPlot2 = xyPlot2 + labs(title = expression("Adenocarcimona or Squamous cell carcinoma based on 2 features  for GSE18842"))
xyPlot2 = xyPlot2 +  aes(size=8) + scale_size(range = c(8, 8))
xyPlot2 = xyPlot2 + guides(size=FALSE)
xyPlot2 = xyPlot2 + theme(legend.text = element_text(size = 12, ))
xyPlot2 = xyPlot2 +scale_colour_discrete(name = "My Legend",
                                       labels=c("sample:AC", "sample:SCC"))


##HERE WE DO ALL THE PLOTS:
dev.off()
#plot and save it - save the two completenesses next to each other
mypath <- file.path(paste(getwd(),"/output",sep=""),"featureCompleteness.png")
png(file=mypath, width=1200, height=800)
par(mfrow=c(1,2))
plot(completePNG)
plot(completePNG2)
dev.off()

#Plot the target distribution here, y axis is the outcome, and save it
# - save the two distributions next to each other
mypath <- file.path(paste(getwd(),"/output",sep=""),"targetDist.png")
png(file=mypath, width=1200, height=800)
par(mfrow=c(1,2))

plot(seq(1,nrow(dframe),1),outcome, xlab="Sample # ", ylab="outcome, 0=AC, 1=SCC")
title("Distribution of outcomes for GSE10245")
plot(seq(1,nrow(dframe2),1),outcome2, xlab="Sample # ", ylab="outcome, 0=sample:control, 1=sample:tumor")
title("Distribution of outcomes for GSE18842")

dev.off()

#plot and save it, each separately
mypath <- file.path(paste(getwd(),"/output",sep=""),"scatterx1x2Y_1.png")
par(mfrow=c(1,2))
png(file=mypath, width=1200, height=800)
print(xyPlot)

dev.off()

mypath2 <- file.path(paste(getwd(),"/output",sep=""),"scatterx1x2Y_2.png")
png(file=mypath2, width=1200, height=800)
print(xyPlot2)

#shut off the device
dev.off()



##HERE WE DO ALL THE SAVING
#save the full data frame for analysis
write.csv(dframe, "output\\mydataframe_1.csv")
#Write data completeness
write.csv(nonMissdf,"output\\mydataframeComplete_1.csv", row.names=FALSE)

#save the full data frame for analysis
write.csv(dframe2, "output\\mydataframe_2.csv")
#Write data completeness
write.csv(nonMissdf2,"output\\mydataframeComplete_2.csv", row.names=FALSE)


