##############################################################################
# Created by Rob Cronin
# Support functions for the main R program
# 
# In here one can find the bootstrapping, crossvalidation and AUC methods
##############################################################################


##Adapted from Robert Carroll's code to create SVM in BMIF315
##This function will return the index and group pairings
##Meaning the first index corresponds to the first group number
##And these can be used to index the data to determine 
##What groups they are in
crossValidate <- function  (data, folds=5, seed=NULL) {
  
  if (!is.null(seed)) set.seed(seed)
  #sample the data to mix up the indicies
  #Then order these indicies by the outcome
  index = order(data$outcome,sample(dim(data)[1]))

  #The groups will just go from 1 to folds and repeat
  group=(1:dim(data)[1])%%folds+1;

  ##return the index and group pairings
   list (index=index, group=group)
}


###Calculate AUC
#Predictions should be the probability estimates from predict
#Values should be the gold standard labels
getAUC = function(predictions,labels) {
  predi = prediction(predictions, labels)
  performance(predi,"auc")@y.values[[1]]
}
 
##This function will bootstrap the data
##With resampling and a test set that is what is not sampled 
##in the training set
##NOT USED!!! in current version 
## 2/23/2014
bootstrap <- function  (data, seed=NULL) {
  if (!is.null(seed)) set.seed(seed)
  index <- 1:nrow(data)
  
  #Obtain the training indexes by sampling from the indexes
  #with resampling
  trainindex <- sample(index, length(index),replace=TRUE)
  
  #Test index will be everything that remains
  testindex<- setdiff(index, trainindex)

  #The train and test set will simply be the rows with the appropriate index
  trainset <- data[trainindex, ]
  testset <- data[testindex, ]
    
  #return all information
  list (trainset=trainset, testset=testset, trainindex=trainindex, testindex=testindex)
  
}


