##Created by Rob Cronin
##BMIF315 - Sp 2014

#Clean the memory
rm(list=ls())

library(e1071)
library(Biobase)
library(GEOquery)
library(ggplot2)
library(ROCR)
library(foreach)
library(randomForest)

#Set to my current directory
setwd("C:/Users/croninrm/Documents/BMI-Fellow-PGY1/BMIF315/Project/Phase3")


#Read back out the data
gset10245 <- read.csv("output/mydataframe_1.csv", check.names=FALSE)
gset18842 <- read.csv("output/mydataframe_2.csv", check.names=FALSE)


#Combine into one data frame for analysis
data = data.frame(rbind(gset10245,gset18842))

#1st column is row names, so make that the row names and then remove the column
row.names(data)=data[,1]
data = data[,-1]

#########################
#Create cross validation classes
#See validationMethods.R for explanation of code
#############################################
source("resources/validationMethods.R")

cross = crossValidate(data,folds=5,seed=323)
groups=max(cross$group)

#cross$group are the groups that each index (cross$index) is under
#Therefore data[cross$index[where(cross$group=i)]] will return the 
#rows which are in group i

##RUN SVM
##Adapted from Robert Carroll's code BMIF315

#ignore is our outcome data in the last column
ignore = c(-ncol(data))

#Iterate through the groups (groups is folds)
MachineLearn <- foreach(i=1:groups, .combine="rbind") %do% { 
  #Train set are the indicies not in i, test set are the indicies out of i
  train=data[cross$index[which(cross$group!=i)],]
  test <- data[cross$index[which(cross$group==i)],]

  #Linear kernel
  model <- svm(x = train[,ignore], y = as.factor(train$outcome),
               kernel="linear", cost=1, 
               type="C-classification", probability=TRUE)
  #Get predictions and auc
  pred <- predict(model, newdata=test[,ignore], probability=TRUE)
  auc = getAUC(attributes(pred)$probabilities[,2],test$outcome)
  cost=1
  #Store in a data frame
  lsvm=data.frame(run=i,model="SVM-linear",auc=auc,cost=1,degree=1,ntree=NA)
  
  #Here we run through the inner cross validation for the polynomial kernel
  innerPSVM = foreach(j=(1:groups)[-i], .combine="rbind") %do% {
    #This is tricky because we just have indicies so subsetting the train set is to take
    #the indexes of the train set (groups in i index) intersected with the groups in the j index for test
    #and the groups outside of the j index for the train
    
    ttrain=data[intersect(cross$index[which((cross$group!=j))], cross$index[which((cross$group!=i))]),]
    ttest=data[intersect(cross$index[which((cross$group==j))], cross$index[which((cross$group!=i))]),]
 
    #Polynomial kernel trying all degrees for an inner cross validation
    foreach(degree=1:4, .combine="rbind") %do% {
      ###This is done again in the Random Forest part
      print("Finding the parameters");print(degree);timestamp()
      
      model <- svm(x = ttrain[,ignore], y = as.factor(ttrain$outcome),
                     kernel="polynomial", cost=1, degree=degree,
                     type="C-classification", probability=TRUE)
      pred <- predict(model, newdata=ttest[,ignore], probability=TRUE)
      auc = getAUC(attributes(pred)$probabilities[,2],ttest$outcome)
      
      #Creating a data frame with the run# and auc, cost and degree
      data.frame(run=i,model="SVM-polynomial",auc=auc,cost=1,degree=degree,ntree=NA)
    }    
  }
  print("After a cross validation finding the parameters");print(i);timestamp()
  
  #Now find the best polynomial SVM by aggregating by the mean AUC for each set
  #of parameters and then taking the max of that average AUC
  best = aggregate(innerPSVM, by=list(innerPSVM$degree,innerPSVM$cost), mean)
  best = best[best$auc==max(best$auc),][1,]
  best$kernel="polynomial"
  
  #Train and test with the best parameters
  model <- svm(x = train[,ignore], y = as.factor(train$outcome),
               kernel="polynomial", cost=best$cost, degree=best$degree,
               type="C-classification", probability=TRUE)
  pred <- predict(model, newdata=test[,ignore], probability=TRUE)
  auc = getAUC(attributes(pred)$probabilities[,2],test$outcome)
  degree=best$degree
  cost=best$cost
  
  #Create data frame with best polynomial SVM params
  psvm=data.frame(run=i,model="SVM-polynomial",auc=auc,cost=best$cost,degree=best$degree,ntree=NA)
  
  
  ##RandomForests
  innerRF = foreach(j=(1:groups)[-i], .combine="rbind") %do% {
    ttrain=data[intersect(cross$index[which((cross$group!=j))], cross$index[which((cross$group!=i))]),]
    ttest=data[intersect(cross$index[which((cross$group==j))], cross$index[which((cross$group!=i))]),]
    foreach(ntree=c(5,10,50,100,300,500), .combine="rbind") %do% {
      #This is tricky because we just have indicies so subsetting the train set is to take
      #the indexes of the train set (groups in i index) intersected with the groups in the j index for test
      #and the groups outside of the j index for the train
      print("Finding the parameters");print(ntree);timestamp()
      
      model.rf<-randomForest(ttrain[,ignore],as.factor(ttrain$outcome), ntree=ntree)
      predict.rf<-predict(model.rf,ttest[,ignore], type="prob")[,2]
      auc<-performance(prediction(predict.rf,ttest$outcome), "auc")@y.values[[1]]
      data.frame(run=i,model="RandomForests",auc=auc,cost=NA,degree=NA,ntree=ntree)
    }
    
  }
  print("After a cross validation finding the parameters");print(i);timestamp()
  
  #Now find the best polynomial SVM by aggregating by the mean AUC for each set
  #of parameters and then taking the max of that average AUC
  best = aggregate(innerRF, by=list(innerRF$ntree), mean)
  best = best[best$auc==max(best$auc),][1,]

  #Train and test with the best parameters
  model.rf<-randomForest(train[,ignore],as.factor(train$outcome), ntree=best$ntree)
  predict.rf<-predict(model.rf,test[,ignore], type="prob")[,2]
  auc<-performance(prediction(predict.rf,test$outcome), "auc")@y.values[[1]]
  rf=data.frame(run=i,model="RandomForests",auc=auc,cost=NA,degree=NA,ntree=best$ntree)  
  
  #Return the best models in best, and the inner** as the runs of the inner cross validation loops
  list(best=rbind(lsvm,psvm,rf),innerRF=innerRF,innerPSVM=innerPSVM)
  
}

#Get the best runs and the inner loops from the list above
bests=MachineLearn[1,]$best
innerRFs = MachineLearn[1,]$innerRF
innerPSVMs = MachineLearn[1,]$innerPSVM

#We have to rbind the above Machine Learning parts
#To get a data frame we can manipulate
for (i in 2:groups){
  bests=rbind(bests,MachineLearn[i,]$best)  
  innerRFs =rbind(innerRFs, MachineLearn[i,]$innerRF)
  innerPSVMs = rbind(innerPSVMs,MachineLearn[i,]$innerPSVM)
}

#Write the outputs of the machine learning algorithms
write.csv(bests,"output/OptimalML.csv",row.names=FALSE)
write.csv(innerRFs,"output/RandomForest-Runs.csv",row.names=FALSE)
write.csv(innerPSVMs,"output/Polynomial-SVM-Runs.csv",row.names=FALSE)

#Calculate the average AUC by model and write it to csv
AUC = tapply(bests$auc, bests$model,mean)
write.csv(data.frame(AUC),"output/averageAucByModel.csv")


#Gaussian kernel NOT USED!!!!!!!!
#foreach(gamma=1:4, .combine="rbind") %do% {
#  model <- svm(x = ttrain[,ignore], y = as.factor(ttrain$outcome),
#               kernel="radial", cost=1, gamma=gamma,
#               type="C-classification", probability=TRUE)
#  pred <- predict(model, newdata=ttest[,ignore], probability=TRUE)
#  auc = getAUC(attributes(pred)$probabilities[,2],ttest$outcome)
#  data.frame(kernel="radial",auc=auc,degree=NA,cost=1,gamma=gamma)
#}    
